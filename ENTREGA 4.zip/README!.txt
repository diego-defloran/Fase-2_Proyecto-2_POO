¿Cómo compilar NutriAssist?
1. Asegúrese de haber descargado la carpeta comprimida llamada ENTREGA 4
2. Extraiga la carpeta
3. Abra Windows Powershell dentro de la carpeta ENTREGA 4
4. Copie y pegue lo siguiente

java -jar NutriAssist.jar

5. Listo!

NOTA: Para evitar el consumo de memoria, todos los .java y .class
se encuentran en la carpeta NutriAssist v1.0 y la carpeta bin respectivamente,
estos se encuentran dentro del repositorio online en GITHUB.
Gracias por su comprensión.

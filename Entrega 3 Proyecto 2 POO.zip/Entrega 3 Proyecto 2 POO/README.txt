¡Bienvenido, estimado usuario!
A continuación tendrá dentro de esta carpeta los diferentes recursos para el buen funcionamiento
de NutriAssist, su asistente nutricional virtual.
---------------------------------INSTRUCCIONES DE USO--------------------------------
1. Deberá extraer la carpeta "Entrega 3 Proyecto 2 POO" de la carpeta .zip que la contiene. Le recomendamos
que la extraiga en su escritorio.

2. Una vez extraida, revise que tenga un total de 6 archivos (incluyendo este) dentro de dicha carpeta.

3. El archivo que contiene al asistente nutricional virtual NutriAssist es: Fase3_Nutri.jar
Los demás archivos con terminación .jar como javacsv, jcommon-1.0.17, y jfreechart-1.0.14 son librerías
externas que emplea el asistente virtual. En adición, tendrá dentro de la misma carpeta, junto con los 
arvhivos .jar, un archivo denominado "UsuariosRegistrados.csv". LE RECOMENDAMOS NO MOVER DE LUGAR ESTOS ARCHIVOS.

4. Para ejecutarlo, deberá presionar sostenidamente su tecla MAYÚS ó Shift junto con un click derecho sobre cualquier
parte dentro de la carpeta "Entrega 3 Proyecto 2 POO". Se le desplegará una ventana emergente con diversas opciones.
Busque y haga click izquierdo sobre la opción "Open in Windows Terminal". Esto le desplegará una ventana emergente
con la terminal de su sistema. 
Otra forma para abrir su terminal para poder ejecutar el archivo .jar, es a través de la barra de direcciones de la carpeta. Únicamente basta
con hacer doble click sobre dicha barra, teclear la expresión: cmd; y, luego ENTER.

5.Con cualquiere de las dos opciones se le desplegará una ventana emergente con la terminal de su sistema. 
Una vez dentro de la terminal, únicamente teclee o copiar/pegar la siguiente instrucción dentro de la línea correspondiente
de su terminal: java -jar Fase3_Nutri.jar

6. Listo! Ya puede disfrutar de su nuevo asistencia nutricional virtual.

Para más información, póngase en contacto con los desarrolladores del programa.

Integrantes:
Dulce González 21763
Elena Rodríguez 21774
Javier Rucal 21779
Diego De Florán 21565

